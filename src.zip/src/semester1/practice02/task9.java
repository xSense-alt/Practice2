package semester1.practice02;

import org.w3c.dom.ls.LSResourceResolver;

public class task9 {
    static void main() {
        int firstNumber = 5;
        double userWeight = 72.5;
        String userCity = "Kyiv";
        boolean isValidUser = true;
        System.out.print(firstNumber + "," + userWeight + "," + userCity + "," + isValidUser);
    }
}

package semester1.practice02;

public class task12 {
    static void main() {
        String login = "ivan.petrenko";
        String domain = "gmail.com";
        String role = "student";
        System.out.println("Користувач " + login + " (роль: " + role + ") " + "має пошту: " + login + "@" + domain);
    }
}

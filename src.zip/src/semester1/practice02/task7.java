package semester1.practice02;

public class task7 {
    static void main() {
        int intVal = 250;
        double doubleVal = intVal;

        System.out.println(intVal);
        System.out.println(doubleVal);
    }
}

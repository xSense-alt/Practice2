package semester1.practice02;

public class task19 {
    static void main() {
        int n = 47;
        int tens =  n / 10;
        int units =  n % 10;
        int p = (tens + units);
        System.out.println("Число: " + n + "." + " Десятки: " + tens + "," + " Одиниці: " + units + "." + " Сума цифр: " + p );
    }
}

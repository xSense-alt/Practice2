package semester1.practice02;

public class task4 {
    static void main() {
        char symbol1 = 'J';
        char symbol2 = 74;
        char symbol3 = '\u004A';

        System.out.println(symbol1);
        System.out.println(symbol2);
        System.out.println(symbol3);

    }
}

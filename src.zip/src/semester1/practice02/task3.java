package semester1.practice02;

public class task3 {
    static void main() {
        float floatValue = 1.1234567f;
        double doubleValue = 1.123456789012345;
        System.out.println(floatValue);
        System.out.println(doubleValue);
    }
}

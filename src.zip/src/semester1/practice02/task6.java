package semester1.practice02;

import java.sql.SQLOutput;
import java.time.DayOfWeek;

public class task6 {
    static void main() {
        final double GRAVITY = 9.81;
        //GRAVITY = 10;
        final int DAYS_IN_WEEK = 7;
        final String UNIVERSITY_NAME = "Львівська Політехніка";

        System.out.println(GRAVITY);
        System.out.println(DAYS_IN_WEEK);
        System.out.println(UNIVERSITY_NAME);
        //Якщо ми запишемо GRAVITY = 10 то Java напише помилку.
        //Ми вже не можемо змінювати константу final double GRAVITY = 9.81
        //Бо тут грає роль саме «final». Воно фіксує нашу константу final
        //І не дає їй змінитись навіть якщо ми пишемо потім інше значення даючи на це помилку

    }
}

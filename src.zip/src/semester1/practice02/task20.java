package semester1.practice02;

public class task20 {
    static void main() {
        int score = 100;
        int sc1 = score += 50;
        int sc2 = score -= 20;
        int sc3 = score *= 2;
        int sc4 = score /= 4;
        System.out.println("Після додавання: " + sc1 + "\nПісля віднімання: " + sc2 + "\nПісля множення: " + sc3 + "\nПісля ділення: " + sc4);
    }
}

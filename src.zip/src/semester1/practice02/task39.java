package semester1.practice02;

public class task39 {
    static void main() {
        int min = -10;
        int max = 35;

        int randomTemp = (int) (Math.random() * (max - min + 1)) + min;

        System.out.println("Погода на завтра: " + randomTemp + "°C");
    }
}

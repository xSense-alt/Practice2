package semester1.practice02;

public class task27 {
    static void main() {
        int speed = 75;
        boolean isSafeSpeed = (speed >= 20) && (speed <= 80);
        System.out.println(isSafeSpeed);
    }
}

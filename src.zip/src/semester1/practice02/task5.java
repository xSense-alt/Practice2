package semester1.practice02;

public class task5 {
    static void main() {
    boolean isJavaFun = true;
    boolean isFishFly = false;
    boolean isSkyBlue = true;

        System.out.println(isJavaFun);
        System.out.println(isFishFly);
        System.out.println(isSkyBlue);
    }
}

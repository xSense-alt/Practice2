package semester1.practice02;

public class test2 {
    static void main() {
        int ammo = 30;
        int magazine = ammo;
        ammo -= 10;

        System.out.println(magazine);
        System.out.println(ammo);
    }
}

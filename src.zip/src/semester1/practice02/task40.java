package semester1.practice02;

public class task40 {
    static void main() {
        double p = 10000.0;
        double r = 12.0;
        int t = 3;

        double total = p * Math.pow(1 + r / 100, t);
        double profit = total - p;

        System.out.println("+------------------------------------+");
        System.out.println("|       ДЕПОЗИТНИЙ КАЛЬКУЛЯТОР       |");
        System.out.println("+------------------------------------+");
        System.out.println("Початкова сума: " + p + " грн");
        System.out.println("Термін: " + t + " роки під " + r + "% річних");
        System.out.printf("Підсумкова сума: %.2f грн%n", total);
        System.out.printf("Чистий прибуток: %.2f грн%n", profit);
        System.out.println("+------------------------------------+");
    }
}

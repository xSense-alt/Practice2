package semester1.practice02;

public class task15 {
    static void main() {
        String protocol = "https://";
        String host = "api.example.com";
        String endpoint = "/users";
        String userId = "42";
        System.out.print("Запит відправлено на: " + protocol + host + endpoint + userId);
    }
}

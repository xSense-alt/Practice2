package semester1.practice02;

public class task22 {
    static void main() {
        int counter = 5;
        System.out.println(++counter);
        System.out.println(counter);
        // На відміну від counter++ оператор ++counter
        // спочатку збільшує значення змінної на 1
        // а вже потім виводить його
        // Тому в консолі одразу отримуємо 6 а не 5
    }
}

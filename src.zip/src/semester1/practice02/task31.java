package semester1.practice02;

public class task31 {
    static void main() {
        boolean hasPassword = true;
        boolean hasSmsCode = true;
        boolean isAccountBlocked = false;
        boolean canLogin = hasPassword && hasSmsCode && !isAccountBlocked;
        System.out.println("Користувач може увійти, якщо в нього є пароль, є смс-код І його акаунт НЕ заблоковано: " + canLogin);
    }
}

package semester1.practice02;

public class task8 {
    static void main() {
        double priceWithPennies = 49.99;
        int roundedPrice = (int) priceWithPennies;
        System.out.println(roundedPrice);
    }
}

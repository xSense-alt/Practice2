package semester1.practice02;

public class task17 {
    static void main() {
        int number = 19;
        int remainder = number % 2;
        System.out.println("Число " + number + " при діленні на 2 дає остачу: " + remainder );
    }
}

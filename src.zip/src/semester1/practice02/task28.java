package semester1.practice02;

public class task28 {
    static void main() {
        int personAge = 70;
        boolean hasFreePass = (personAge < 7) || (personAge >= 65);
        System.out.println("Вік: " + personAge + "." + "Право на безкоштовний рооїзд: " + hasFreePass);
    }
}

package semester1.practice02;

public class task16 {
    static void main() {
        String language = "Java";
        int level = 1;
        boolean isReady = true;
        System.out.println("Мова: " + language + " | " + "Рівень: " + level + " | " + "Готовність до практики: " +isReady );
    }
}

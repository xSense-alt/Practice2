package semester1.practice02;

public class Practice02 {
    static void main() {
        int age = 17;
        double height = 1.78;
        char firstLetter = 'S';
        boolean isStudent = true;

        System.out.println(age);
        System.out.println(height);
        System.out.println(firstLetter);
        System.out.println(isStudent);

    }
}





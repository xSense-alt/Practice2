package semester1.practice02;

public class task38 {
    static void main() {
        int dice = (int) (Math.random() * 6) + 1;

        System.out.println("Випало на кубику: " + dice);
    }
}

package semester1.practice02;

public class task18 {
    static void main() {
        int totalSeconds = 385;
        int minutes = totalSeconds / 60;
        int seconds = totalSeconds % 60;
        System.out.println("385 секунд + " + minutes + " хв " + seconds + " сек");

    }
}

package semester1.practice02;

public class task23 {
    static void main() {
        int grade1 = 4; int grade2 = 5; int grade3 = 4;
        double average = (grade1 + grade2 + grade3) / 3.0;
        System.out.println("Середній бал: " + average);
    }
}

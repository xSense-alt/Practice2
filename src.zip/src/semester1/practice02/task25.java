package semester1.practice02;

public class task25 {
    static void main() {
        int userAge = 17;
        boolean isAdult = userAge >= 18;
        System.out.println("Вік: " + userAge + ". " + "Чи є повнолітнім: " + isAdult);
    }
}

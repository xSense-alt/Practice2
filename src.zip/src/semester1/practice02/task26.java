package semester1.practice02;

public class task26 {
    static void main() {
        int x = 15; int y = 20;
        System.out.println("x == y: " + (x == y));
        System.out.println("x != y: " + (x != y));
        System.out.println("x > y: " + (x > y));
    }
}

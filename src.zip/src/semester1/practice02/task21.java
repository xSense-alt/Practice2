package semester1.practice02;

public class task21 {
    static void main() {
        int counter = 5;
        System.out.println(counter++);
        System.out.println(counter);
        // Спочатку вивелося 5, тому що оператор counter++
        // спочатку використовує поточне значення змінної
        // а вже після цього збільшує його на 1
        // Тому при наступному виведенні ми отримали 6.

    }
}

package semester1.practice02;

public class task13 {
    static void main() {
        String productName = "Ноутбук";
        int quantity = 2;
        double pricePerUnit = 24500.50;
        System.out.println("ЧЕК:\nТовар: " + productName + "\nКількість: " + quantity + "\nЦіна: " + pricePerUnit);
    }
}

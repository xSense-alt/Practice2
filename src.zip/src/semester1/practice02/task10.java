package semester1.practice02;

public class task10 {
    static void main() {
        String firstName = "Тарас";
        String lastName = "Шевченко";
        int age = 47;
        System.out.println("Мене звати " + firstName + " " + lastName + " мені " + age + " років.");


    }
}

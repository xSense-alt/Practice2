package semester1.practice02;

public class task30 {
    static void main() {
        int number = 30;
        int number1 = 25;
        boolean isDivisibleByBoth = (number % 3 == 0) && (number % 5 == 0);
        boolean isDivisibleByBoth1 = (number1 % 3 == 0) && (number1 % 5 == 0);
        System.out.println(isDivisibleByBoth);
        System.out.println(isDivisibleByBoth1);
    }
}

package semester1.practice02;

public class test {
    static void main() {
        int health = 440;
        health -= 50;
        int ammo = 30;
        ammo -= 18;
        boolean isAlive = true;
        System.out.println(health);
        System.out.println(ammo);
        System.out.println(isAlive);
    }
}

package semester1.practice02;

public class task24 {
    static void main() {
        double celsius = 25.0;
        double farengeit = (celsius*1.8+32);
        double calvin = (celsius + 273.15);
        System.out.println(celsius + " С" + " = " + farengeit + " F");
        System.out.println(celsius + " С" + " = " + calvin + " К");
    }
}
